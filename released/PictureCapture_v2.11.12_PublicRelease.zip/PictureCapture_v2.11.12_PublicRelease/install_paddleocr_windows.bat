@echo off
setlocal
cd /d "%~dp0"
py -3 -m pip install -r requirements-paddleocr.txt
if errorlevel 1 (
  echo.
  echo PaddleOCR installation failed. Review the error above.
  pause
  exit /b 1
)
py -3 -c "from paddleocr import PaddleOCR; import paddle; print('PaddleOCR installation OK; Paddle', paddle.__version__)"
pause
