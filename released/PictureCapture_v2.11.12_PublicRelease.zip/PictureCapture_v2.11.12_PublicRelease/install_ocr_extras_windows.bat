@echo off
setlocal
cd /d "%~dp0"

set "PC_PYTHON=.venv\Scripts\python.exe"
if not exist "%PC_PYTHON%" set "PC_PYTHON=py -3"

echo Installing Google Lens connector...
%PC_PYTHON% -m pip install --upgrade -r requirements-lens.txt
if errorlevel 1 goto :failed

echo.
where tesseract.exe >nul 2>nul
if errorlevel 1 (
  echo Tesseract executable was not found in PATH.
  echo Install Tesseract 5 with spa and eng language data, then use
  echo Settings - Detect OCR Engines to resolve the executable path.
) else (
  echo Tesseract found:
  where tesseract.exe
)

echo.
echo OCR extras installation finished.
pause
exit /b 0

:failed
echo.
echo Installation failed. Review the message above.
pause
exit /b 1

