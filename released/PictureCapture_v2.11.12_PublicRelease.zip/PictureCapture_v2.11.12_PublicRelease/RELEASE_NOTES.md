# Picture Capture v2.11.12 Public Release Notes

## 发布定位

这是 v2.11.12 的干净公开发布包。功能代码与 v2.11.12 保持一致，仅整理了发行目录和用户文档；内部分析、历史验证报告、build 缓存、egg-info、测试目录没有放入公开 ZIP。

## v2.11 系列主要能力

- PPP 自动插图识别、人工编辑、名称、删除、矩形四边拖动。
- PPP 名称可与词条建立关联，Crop Plan 在词条切图前判断完整包含、部分相交或外部。
- 主界面完整切图预览，正式切图与预览共用同一计划。
- 统一【切图设置】，集中管理词条与插图切图。
- 可关闭“综合插图计算切图信息”，适合插图基本都位于词条内部的词典。
- 页面列表增加插图数量列，页面/已画线/填充状态/插图支持排序，后三列可隐藏。
- PDIC 备份/恢复、PDIC 排序修复。
- 修复 PDIC 排序严格按“栏号 → Y”，不使用 X。
- 大项目批量填词不再逐页解码整张图片；PDIC 备份和 PicDic 索引采用后台流式 I/O。
- `wordslist.txt` 支持 10 万–20 万行规模，校对 GUI 使用虚拟窗口显示。
- 新增【导出PicDic索引】，格式为 `WORD<TAB>xx.xx<TAB>yy.yy<TAB>page`，不带百分号。

## v2.10 系列主要能力

- Dictionary Profile v2：按版面类型管理 OCR、结构语法、左缘/粗体/空白证据和横线定位。
- 内置经典版面 Profile 与代表词典预览。
- 支持葡语、意大利语、西语编号 POS、中文圆点/拼音、中文括号/大字等不同词头结构。
- `wordslist.txt` 可自定义路径，校对窗口可即时切换参考词表。

## 验证

发行前基线已通过：

- `pytest`：205 项通过。
- 内置 unittest：70 项通过。
- ZIP 完整性与 Python 编译检查通过。

## 公开包不包含

- `VALIDATION_*.md`
- `ANALYSIS_*.md`
- `LEGACY_FUNCTION_MAP.md`
- `V2_ARCHITECTURE.md`
- `tests/`
- `build/`
- `src/*.egg-info/`
- `__pycache__/` / `.pyc`

这些属于开发与内部验证资料，不影响程序运行。
