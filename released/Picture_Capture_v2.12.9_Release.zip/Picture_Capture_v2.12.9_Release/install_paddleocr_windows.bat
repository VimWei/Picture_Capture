@echo off
setlocal
cd /d "%~dp0"

echo [1/3] Checking PaddlePaddle runtime...
py -3 -c "import paddle; print('Existing Paddle runtime:', paddle.__version__)" >nul 2>&1
if errorlevel 1 (
  echo No Paddle runtime found. Installing official stable CPU runtime 3.3.0...
  py -3 -m pip install paddlepaddle==3.3.0 -i https://www.paddlepaddle.org.cn/packages/stable/cpu/
  if errorlevel 1 goto :fail
) else (
  echo Existing Paddle runtime detected. It will be preserved ^(CPU or GPU^).
)

echo [2/3] Installing PaddleOCR with PP-OCRv6 support...
py -3 -m pip install -r requirements-paddleocr.txt
if errorlevel 1 goto :fail

echo [3/3] Verifying environment...
py -3 -c "import importlib.metadata as m, paddle; from paddleocr import PaddleOCR; print('PaddleOCR',m.version('paddleocr')); print('PaddleX',m.version('paddlex')); print('Paddle',paddle.__version__); print('CUDA compiled:',paddle.device.is_compiled_with_cuda())"
if errorlevel 1 goto :fail

echo.
echo PaddleOCR / PP-OCRv6 environment is ready.
pause
exit /b 0

:fail
echo.
echo PaddleOCR installation failed. Review the error above.
pause
exit /b 1
