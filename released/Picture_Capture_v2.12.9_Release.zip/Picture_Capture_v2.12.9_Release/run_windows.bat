@echo off
setlocal
cd /d "%~dp0"

rem v2.12.8: official OpenCC and the legacy reimplementation share the same
rem top-level `opencc` module.  Uninstalling the legacy package can remove
rem overlapping module files even when official OpenCC metadata remains.
set "OPENCC_MIGRATED=0"
py -3 -m pip show opencc-python-reimplemented >nul 2>&1
if not errorlevel 1 (
  echo [Picture Capture] Replacing legacy opencc-python-reimplemented with official OpenCC...
  py -3 -m pip uninstall -y opencc-python-reimplemented
  if errorlevel 1 (
    pause
    exit /b 1
  )
  set "OPENCC_MIGRATED=1"
)

if "%OPENCC_MIGRATED%"=="1" (
  echo [Picture Capture] Repairing official OpenCC module files...
  py -3 -m pip install --upgrade --force-reinstall "opencc>=1.4.2,<2"
  if errorlevel 1 (
    pause
    exit /b 1
  )
)

py -3 -m pip install -r requirements.txt
if errorlevel 1 (
  pause
  exit /b 1
)

rem Metadata saying "OpenCC installed" is not enough.  Verify import,
rem t2s.json loading and an actual conversion; self-heal once if needed.
py -3 -c "import opencc; c=opencc.OpenCC('t2s.json'); assert c.convert('繁體中文')" >nul 2>&1
if errorlevel 1 (
  echo [Picture Capture] OpenCC runtime check failed. Repairing official OpenCC...
  py -3 -m pip install --upgrade --force-reinstall "opencc>=1.4.2,<2"
  if errorlevel 1 (
    pause
    exit /b 1
  )
  py -3 -c "import opencc; c=opencc.OpenCC('t2s.json'); print(c.convert('繁體中文'))"
  if errorlevel 1 (
    echo [Picture Capture] OpenCC is installed but cannot initialize. Please check the error above.
    pause
    exit /b 1
  )
)

py -3 run.py
if errorlevel 1 (
  pause
)
