# CC-CEDICT 安装说明

Picture Capture v2.12.8 支持本地 CC-CEDICT 词典核验。CC-CEDICT 不属于 Python/PIP 软件包，不需要执行 `pip install`。

## 安装步骤

1. 在浏览器打开 CC-CEDICT 官方下载页：
   https://www.mdbg.net/chinese/dictionary?page=cc-cedict
2. 下载 UTF-8 版本，推荐 ZIP：`cedict_1_0_ts_utf-8_mdbg.zip`。
3. 打开 Picture Capture 的【词条校对】窗口。
4. 点击 `CC-CEDICT(未装)`。
5. 选择【是】，然后直接选择刚下载的 ZIP 文件；无需手动解压。
6. 安装成功后按钮会变为 `CC-CEDICT(?)`；选择词条或点【立即】后显示 `CC-CEDICT(√)` / `CC-CEDICT(×)`。

## 本地位置

Windows 默认保存到：

`%LOCALAPPDATA%\PictureCapture\dictionaries\cc-cedict\`

词典为当前 Windows 用户的所有 Picture Capture 项目共享，不会复制到各项目的 `_PictureCapture` 目录。

## 数据与许可

CC-CEDICT 由 MDBG 提供下载，采用 CC BY-SA 4.0。Picture Capture 只读取用户下载的本地数据库，不自动抓取 MDBG 查询网页，也不会修改 CC-CEDICT 内容。
